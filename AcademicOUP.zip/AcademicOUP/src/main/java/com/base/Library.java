package com.base;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Library 
{

	protected WebDriver driver;
		Properties prop;
		
		
	//Launching a WebBrowser	
	public void launchBrowser() throws IOException
	{
		//Locating the Path of the file
		FileInputStream objfile = new 	FileInputStream(new File("C:\\Users\\lenovo\\eclipse-workspace1\\AcademicOUP\\src\\test\\resources\\ConfigurationProperty\\config.property"));
		//Creating the object to the property file
		prop = new Properties();
		
		//Loading the property file into the object
		prop.load(objfile);
		
		//Initialising the browser name
		String browserName = prop.getProperty("browser");
		
		try
		{   
			//Checking the browser name 
		      if(browserName.equalsIgnoreCase("chrome"))
		     {
		    	  //Setting the ChromeDriver Property
			   System.setProperty("webdriver.chrome.driver", "./chromedriver.exe");
			   
			   //Initialising the Driver
			   driver = new ChromeDriver();
			 }
		   else 
			   //Checking the browser name
			  if(browserName.equalsIgnoreCase("firefox"))
			 {
				  //Initiialising the Driver
				driver = new FirefoxDriver();
			 }
		      
		      //Maximizing the Window
		  driver.manage().window().maximize();
		  //Implicitly Waiting the Driver
		  driver.manage().timeouts().implicitlyWait(90, TimeUnit.SECONDS);
		  //Getting the url from the property file
		  driver.get(prop.getProperty("url"));
		
		}
		
		  catch(WebDriverException e)
		{
			  //printing the message
			System.out.println("browser could not be launched");
		}
		
	}

	  public void quit()
	{
		  //Closing the driver
		driver.close();
	}

}

	
	

