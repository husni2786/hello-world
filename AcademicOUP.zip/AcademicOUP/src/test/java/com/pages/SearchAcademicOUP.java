package com.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SearchAcademicOUP 
{
		    WebDriver driver;
			
		    //Identifying the Locators
			@FindBy(id = "MicrositeSearchTerm")
			WebElement searchtext;
			@FindBy(xpath = "//*[@id=\'MicrositeSearchIcon\']")
			WebElement searchbtn;
			
			
			//Pointing to the Current Driver
			public SearchAcademicOUP(WebDriver driver)
			{
			    PageFactory.initElements(driver, this);
				this.driver=driver;
			}
			
			
			//Entering the text in the Search Text Box
			public void search_data(String data)
			{
				searchtext.sendKeys(data);
			}
			
			//Clicking on the Search Icon
			public void search_button()
			{
			    WebDriverWait wait = new WebDriverWait(driver , 20);
				wait.until(ExpectedConditions.elementToBeClickable(searchbtn));
				 
				searchbtn.click();
				
	         }
			
	
			

}
