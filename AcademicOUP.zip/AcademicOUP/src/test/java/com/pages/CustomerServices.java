package com.pages;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class CustomerServices 
{
	          Actions action;
			WebDriver driver;
			
			//Identifying the Locators
			@FindBy(linkText = "Customer Services")
			WebElement customerservicebtn;
			@FindBy(linkText = "About Us")
			WebElement aboutus; 
			
			//Pointing to the Current Driver
			public CustomerServices(WebDriver driver)
			{
				
				PageFactory.initElements(driver, this);
				this.driver=driver;
			}
			
			//Mouse mover and selecting actions are performed
			public void customer_serviceinspect()
			{
				  action = new Actions(driver);
				  action.moveToElement(customerservicebtn).build().perform();
				  Actions seriesofactions = action.moveToElement(aboutus).click();
				   seriesofactions.build().perform();
				
			}
			
}
			
			






