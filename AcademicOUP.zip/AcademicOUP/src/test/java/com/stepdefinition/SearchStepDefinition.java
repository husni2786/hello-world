package com.stepdefinition;

import java.io.IOException;

import org.apache.log4j.Logger;

import com.base.Library;
import com.pages.LoginAcademicOUP;
import com.pages.SearchAcademicOUP;
import com.seleniumutility.SeleUtil;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class SearchStepDefinition extends Library
{
	
	SeleUtil util;
	SearchAcademicOUP text;
	
	Logger LOG = Logger.getLogger(LoginAcademicOUP.class.getName());
	
	//Launching the Browser
   @Given("^I launch the Login Page$")
       public void i_launch_the_Login_Page() throws IOException 
       {
            launchBrowser();
            LOG.info("I Launched The Browser");
	        System.out.println("Browser is Launched");
	        text = new SearchAcademicOUP(driver); 
	   }

   //Taking the ScreenShot
   @When("^Search Page is opened$")
        public void search_Page_is_opened() 
       {
         System.out.println("Search Page is Opened");
	     
       }

   //Entering the text in the Search Text Box
    @Then("^I enter \"([^\"]*)\"$")
        public void i_enter(String searchtext) 
       {	  
	     text.search_data(searchtext);
	     LOG.info("I Enter the text in the Search Box");
	     System.out.println("Text is Entered");
	   }

    //Click on the Search Icon 
   @Then("^I click on the search button$")
         public void i_click_on_the_search_button() throws InterruptedException 
       {
         text.search_button();
         LOG.info("Clicked Search Button");
         System.out.println("I Click on Search Button");
         
         Thread.sleep(2000);
         
         util = new SeleUtil(driver);
	     util.ScreenShot("C:\\Users\\lenovo\\eclipse-workspace1\\AcademicOUP\\src\\test\\resources\\ScreenShot\\SearchAcademicOUP.png");
	     LOG.info("Screen taken Successfully");
	     System.out.println("ScreenShot is Successfully Taken");
	     
	     driver.close();

       }
	
}
